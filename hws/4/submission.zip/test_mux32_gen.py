from random import Random, random


n = ""
for i in range(32):
    print(f"    in{i:02} = 6'd{(i+1):02};")

